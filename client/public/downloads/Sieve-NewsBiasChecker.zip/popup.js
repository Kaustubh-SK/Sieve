document.addEventListener('DOMContentLoaded', function() {
  // Get current tab URL
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    if (tabs && tabs.length > 0) {
      try {
        const currentUrl = new URL(tabs[0].url);
        const hostname = currentUrl.hostname;
        document.getElementById('url').textContent = hostname;
      } catch (error) {
        console.error("Error parsing URL:", error);
        document.getElementById('url').textContent = "Error parsing URL";
      }
    } else {
      document.getElementById('url').textContent = "No active tab";
    }
  });

  // Button event listener
  document.getElementById('check-bias').addEventListener('click', function() {
    const resultContainer = document.getElementById('bias-result');
    const loadingIndicator = document.getElementById('loading-indicator');
    
    // Get current tab URL
    chrome.tabs.query({active: true, currentWindow: true}, async function(tabs) {
      if (!tabs || tabs.length === 0) {
        resultContainer.innerHTML = 'Error: No active tab detected.';
        return;
      }
      
      const url = tabs[0].url;
      let hostname = "unknown";
      
      try {
        hostname = new URL(url).hostname;
      } catch (error) {
        console.error("Error parsing URL:", error);
        resultContainer.innerHTML = 'Error parsing URL: ' + error.message;
        return;
      }
      
      // Show loading indicator
      loadingIndicator.style.display = 'block';
      resultContainer.innerHTML = '';
      
      // Create a timeout to handle cases where the background script doesn't respond
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => {
          reject(new Error('Request timed out after 30 seconds'));
        }, 30000);
      });
      
      try {
        // Send message to background script to analyze the URL
        const analyzePromise = new Promise((resolve, reject) => {
          chrome.runtime.sendMessage(
            { action: 'analyzeBias', url: url },
            function(response) {
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
                return;
              }
              resolve(response);
            }
          );
        });
        
        // Race between the analysis and the timeout
        const response = await Promise.race([analyzePromise, timeoutPromise]);
        
        // Hide loading indicator
        loadingIndicator.style.display = 'none';
        
        if (response && response.result) {
          // Parse the result to separate the bias rating and explanation
          const resultText = response.result;
          const lines = resultText.split('\n');
          
          if (lines.length >= 2) {
            const ratingLine = lines[0]; // "Bias Rating: X"
            const explanationLine = lines[1]; // "Explanation: Y"
            
            // Extract the actual rating and explanation
            const rating = ratingLine.replace('Bias Rating:', '').trim();
            const explanation = explanationLine.replace('Explanation:', '').trim();
            
            // Determine the color based on the political leaning
            let ratingColor = '#64ffda'; // Default accent color
            
            // Right-leaning colors (red spectrum)
            if (rating.includes('Far Right')) {
              ratingColor = '#d32f2f'; // Deep red
            } else if (rating.includes('Right-Leaning')) {
              ratingColor = '#f44336'; // Medium red
            } else if (rating.includes('Center-Right')) {
              ratingColor = '#ef9a9a'; // Light red
            }
            // Left-leaning colors (blue spectrum)
            else if (rating.includes('Far Left')) {
              ratingColor = '#0d47a1'; // Deep blue
            } else if (rating.includes('Left-Leaning')) {
              ratingColor = '#2196f3'; // Medium blue
            } else if (rating.includes('Center-Left')) {
              ratingColor = '#90caf9'; // Light blue
            }
            // Center/Neutral colors (green spectrum)
            else if (rating.includes('Center') || rating.includes('Neutral')) {
              ratingColor = '#4caf50'; // Green
            }
            
            // Display them in a cleaner format with appropriate color
            resultContainer.innerHTML = `
              <p style="color: ${ratingColor}; font-weight: bold; font-size: 16px;">${rating}</p>
              <p>${explanation}</p>
            `;
          } else {
            // Fallback if the expected format is not found
            resultContainer.innerHTML = resultText;
          }
        } else {
          resultContainer.innerHTML = 'Error analyzing the website. Please try again.';
        }
      } catch (error) {
        loadingIndicator.style.display = 'none';
        console.error("Error during analysis:", error);
        resultContainer.innerHTML = `Error: ${error.message}<br><br>Please try again or check the browser console for more details.`;
      }
    });
  });
}); 