# Sieve - News Bias Checker

A Chrome extension that checks the political bias of news websites using a curated database of media sources.

## Features

- Automatically detects when you're browsing a news website
- Analyzes the political bias of news sources
- Provides a rating and explanation for the bias detection
- Supports major international and Indian news websites

## Supported News Sources

### International News Sources
- Fox News
- CNN
- New York Times
- Wall Street Journal
- Associated Press
- Reuters
- BBC
- The Guardian
- Fox Business
- HuffPost
- Breitbart
- MSNBC
- Bloomberg

### Indian News Sources
- ANI (Asian News International)
- Times of India (IndiaTime.com)
- NDTV (NDTV.com)
- Hindustan Times (HindustanTimes.com)
- Indian Express (IndianExpress.com)
- The Hindu (TheHindu.com)
- ABP News (ABPLive.com)
- News18 (News18.com)
- India.com
- DNA India (DNAIndia.com)
- Deccan Chronicle (DeccanChronicle.com)
- Firstpost (Firstpost.com)
- Business Standard (Business-Standard.com)
- Economic Times (EconomicTimes.Indiatimes.com)
- LiveMint (LiveMint.com)
- Outlook India (OutlookIndia.com)
- Amar Ujala (AmarUjala.com)
- Zee News (ZeeNews.India.com)
- Scroll.in
- The Wire (TheWire.in)
- The Quint (TheQuint.com)
- Swarajya Magazine (SwarajyaMag.com)
- The Print (ThePrint.in)
- The News Minute (TheNewsMinute.com)
- Republic World (RepublicWorld.com)
- Dainik Bhaskar (DainikBhaskar.com)
- Jagran (Jagran.com)
- OneIndia (OneIndia.com)
- India TV News (IndiaTVNews.com)
- News18 Hindi (News18Hindi.com)
- Times Now (TimesNowNews.com)
- Financial Express (FinancialExpress.com)
- The Week (TheWeek.in)
- The Statesman (TheStatesman.com)
- Mid-Day (Mid-Day.com)
- Business Today (BusinessToday.in)
- The Telegraph India (TheTelegraphIndia.com)
- Free Press Journal (FreePressJournal.in)
- The New Indian Express (TheNewIndianExpress.com)
- The Tribune (TheTribuneIndia.com)
- Asian Age (AsianAge.com)
- NewsX (NewsX.com)
- India Today (IndiaToday.in)
- The Pioneer (ThePioneer.com)
- Lokmat (Lokmat.com)
- Sakal Times (SakalTimes.com)
- Malayala Manorama (ManoramaOnline.com)
- Mathrubhumi (Mathrubhumi.com)
- DeshGujarat (DeshGujarat.com)
- Greater Kashmir (GreaterKashmir.com)

## Setup Instructions

1. Clone or download this repository to your local machine.

2. **Create icon files**: Before loading the extension, you need to create icon files in the following sizes:
   - `images/icon16.png` (16x16 pixels)
   - `images/icon48.png` (48x48 pixels)
   - `images/icon128.png` (128x128 pixels)
   
   You can create these icons using any image editor or icon generator.

3. **Load the extension in Chrome**:
   - Open Chrome and navigate to `chrome://extensions/`
   - Enable "Developer mode" by toggling the switch in the top right
   - Click "Load unpacked" and select the folder containing this extension
   - The extension should now appear in your toolbar

## Usage

1. Visit any news website
2. Click on the Sieve extension icon in your toolbar
3. Click "Check Bias" to analyze the current website
4. Review the bias rating and explanation

## How It Works

The extension contains a database of news sources with predetermined bias ratings. When you visit a news website, the extension matches the domain against this database and provides the corresponding bias assessment.

For news sites not in the database, the extension will indicate that the source hasn't been analyzed yet.

## Privacy Considerations

This extension only analyzes the domain of the website you're visiting. No content from the page is collected or transmitted. 