// Cache for storing bias analysis results
const biasCache = {};

// Listen for messages from content scripts and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'newsPageDetected') {
    // If we detect a news page, we could show a notification or badge
    chrome.action.setBadgeText({ text: "NEWS" });
    chrome.action.setBadgeBackgroundColor({ color: "#4285F4" });
    
    // We could also automatically analyze the site, but for now we'll wait for user action
    console.log("News site detected: " + request.url);
  }
  
  else if (request.action === 'analyzeBias') {
    // Check if we have a cached result
    if (biasCache[request.url]) {
      console.log("Using cached result for: " + request.url);
      sendResponse({ result: biasCache[request.url] });
      return true;
    }
    
    // Get the active tab
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      if (!tabs || tabs.length === 0) {
        sendResponse({ result: "Error: Could not access the current tab." });
        return;
      }
      
      const currentTab = tabs[0];
      
      // Extract information directly from the tab if possible
      const hostname = new URL(currentTab.url).hostname;
      const title = currentTab.title || "";
      
      // Analyze the site based on its domain
      analyzeSite(request.url, hostname, title, sendResponse);
    });
    
    // Return true to indicate we'll respond asynchronously
    return true;
  }
});

// Function to analyze a site based on its domain
function analyzeSite(url, hostname, title, sendResponse) {
  console.log("Analyzing site:", hostname);
  
  try {
    // Generate bias analysis based on predefined responses
    const biasAnalysis = getBiasAnalysis(url, hostname);
    
    // Cache the result
    biasCache[url] = biasAnalysis;
    
    // Send response back to popup
    sendResponse({ result: biasAnalysis });
  } catch (error) {
    console.error("Error analyzing site:", error);
    sendResponse({ result: "Error analyzing bias: " + error.message });
  }
}

// Function to get bias analysis based on domain
function getBiasAnalysis(url, domain) {
  console.log("Getting bias analysis for:", domain);
  
  // Extract domain from URL
  try {
    if (domain.includes("//")) {
      domain = domain.split("//")[1];
    }
    if (domain.includes("/")) {
      domain = domain.split("/")[0];
    }
    if (domain.startsWith("www.")) {
      domain = domain.substring(4);
    }
  } catch (e) {
    console.error("Error parsing domain:", e);
  }
  
  console.log("Parsed domain for analysis:", domain);
  
  // Predefined responses based on news sites
  
  // International News Sites
  if (domain.includes("foxnews")) {
    return "Bias Rating: Right-Leaning\nExplanation: Fox News typically presents news from a conservative perspective, often favoring Republican policies and politicians.";
  } else if (domain.includes("cnn")) {
    return "Bias Rating: Left-Leaning\nExplanation: CNN tends to present news from a liberal perspective, often more favorable to Democratic policies and politicians.";
  } else if (domain.includes("nytimes")) {
    return "Bias Rating: Center-Left\nExplanation: The New York Times generally presents news with a slight liberal perspective, particularly on social issues.";
  } else if (domain.includes("wsj")) {
    return "Bias Rating: Center-Right\nExplanation: The Wall Street Journal's news reporting is generally balanced, while its opinion section leans conservative, particularly on economic issues.";
  } else if (domain.includes("apnews") || domain.includes("reuters")) {
    return "Bias Rating: Center/Neutral\nExplanation: Associated Press is generally regarded as presenting balanced, factual reporting with minimal bias.";
  } else if (domain.includes("bbc")) {
    return "Bias Rating: Center/Neutral\nExplanation: The BBC strives for impartiality and balance in its reporting, though it is sometimes criticized for having a slight liberal lean on social issues.";
  } else if (domain.includes("theguardian")) {
    return "Bias Rating: Left-Leaning\nExplanation: The Guardian generally presents news from a liberal or progressive perspective, particularly on social and economic issues.";
  } else if (domain.includes("foxbusiness")) {
    return "Bias Rating: Right-Leaning\nExplanation: Fox Business tends to present economic and business news from a conservative or free-market perspective.";
  } else if (domain.includes("huffpost") || domain.includes("huffingtonpost")) {
    return "Bias Rating: Left-Leaning\nExplanation: HuffPost (formerly Huffington Post) generally presents news from a liberal or progressive perspective.";
  } else if (domain.includes("breitbart")) {
    return "Bias Rating: Far Right\nExplanation: Breitbart News typically presents news from a far-right perspective, often featuring populist and nationalist viewpoints.";
  } else if (domain.includes("msnbc")) {
    return "Bias Rating: Left-Leaning\nExplanation: MSNBC generally presents news from a liberal perspective, often more favorable to Democratic policies and politicians.";
  } else if (domain.includes("bloomberg")) {
    return "Bias Rating: Center\nExplanation: Bloomberg News typically provides factual reporting with a focus on business and economic news, with a generally balanced perspective.";
  } 
  
  // Indian News Sites
  else if (domain.includes("aninews")) {
    return "Bias Rating: Center-Right\nExplanation: ANI (Asian News International) is generally considered to present news with a slight right-of-center perspective in the Indian political context, often viewed as favorable to the current government.";
  } else if ((domain.includes("indiatimes") && !domain.includes("economictimes")) || domain.includes("timesofindia")) {
    return "Bias Rating: Center-Right\nExplanation: IndiaTimes.com is classified as center-right because its reporting and story selection consistently favor the right-leaning ruling party in India, reflecting a slight to moderate conservative bias.";
  } else if (domain.includes("ndtv")) {
    return "Bias Rating: Far Right\nExplanation: This due to its majority ownership by the Adani Group, whose close ties to the ruling BJP have led to a marked reduction in government criticism and a more compliant editorial stance. This represents a clear shift from its earlier independent, center-left positioning under the Roys.";
  } else if (domain.includes("hindustantimes")) {
    return "Bias Rating: Center-Left\nExplanation: This is due to its ownership by Shobhana Bhartia, a Congress-nominated parliamentarian, and its consistent support for liberal, secular, and progressive policies aligned with the Congress Party.";
  } else if (domain.includes("indianexpress")) {
    return "Bias Rating: Center-Left\nExplanation: IndianExpress.com is classified as center left due to its independent ownership by the Goenka family, a strong tradition of investigative journalism, and editorial positions that consistently favor liberal and progressive causes while holding those in power accountable.";
  } else if (domain.includes("thehindu")) {
    return "Bias Rating: Center-Left\nExplanation: TheHindu.com is center-left due to its legacy of secular, progressive journalism under the Kasturi family's ownership and its consistent criticism of right-wing policies, particularly targeting the BJP-led government.";
  } else if (domain.includes("abplive")) {
    return "Bias Rating: Center-Right\nExplanation: ABPLive.com leans center-right due to its ownership by the Sarkar family, which has aligned its Hindi digital and TV platforms with pro-BJP content, and editorial practices that amplify government achievements while minimizing criticism.";
  } else if (domain.includes("news18") && !domain.includes("news18hindi")) {
    return "Bias Rating: Far Right\nExplanation: News18.com is classified as far right due to its Reliance Industries ownership, which aligns editorial policy with the BJP and Modi government, and independent bias ratings confirming a consistent right-leaning slant.";
  } else if (domain.includes("india.com")) {
    return "Bias Rating: Far Right\nExplanation: India.com is classified as far right due to its Zee Media/Essel Group ownership under Subhash Chandra, whose political affiliations and editorial direction strongly favor the BJP and right-leaning narratives.";
  } else if (domain.includes("dnaindia")) {
    return "Bias Rating: Far Right\nExplanation: DNAIndia.com is classified as far right due to its ownership by the Essel Group under Subhash Chandra, whose political and editorial influence consistently favors the BJP and conservative viewpoints.";
  } else if (domain.includes("deccanchronicle")) {
    return "Bias Rating: Center-Right\nExplanation: DeccanChronicle.com is classified as center right due to its consistent editorial support for right-leaning government policies and moderate conservative language, as confirmed by independent media bias ratings.";
  } else if (domain.includes("firstpost")) {
    return "Bias Rating: Center-Right\nExplanation: Firstpost.com leans center right due to its Reliance-owned Network18 Group structure, which aligns editorial policy with BJP interests, and a documented history of avoiding criticism of the Modi government.";
  } else if (domain.includes("business-standard")) {
    return "Bias Rating: Center-Right\nExplanation: Business-Standard.com is classified as center right due to its Kotak Mahindra Bank ownership and editorial leadership with a business-focused, pro-market approach that often supports government economic policies.";
  } else if (domain.includes("economictimes")) {
    return "Bias Rating: Center-Right\nExplanation: This is classified as center-right because its reporting and story selection consistently favor the right-leaning ruling party in India, reflecting a slight to moderate conservative bias.";
  } else if (domain.includes("livemint")) {
    return "Bias Rating: Center-Left\nExplanation: LiveMint.com is classified as center left due to its HT Media ownership with Congress Party ties and an editorial team rooted in centrist and progressive journalism, resulting in a blend of pro-market analysis and socially liberal coverage.";
  } else if (domain.includes("outlookindia")) {
    return "Bias Rating: Center-Left\nExplanation: OutlookIndia.com is classified as center left because of its history of progressive, anti-establishment reporting and editorial leadership rooted in secular, liberal values, despite occasional moderation driven by business interests.";
  } else if (domain.includes("amarujala")) {
    return "Bias Rating: Center-Right\nExplanation: AmarUjala.com is classified as center right due to its exclusive Maheshwari family ownership with direct BJP affiliations and an editorial team with a history in right-leaning newsrooms, resulting in consistently pro-BJP and conservative coverage.";
  } else if (domain.includes("zeenews")) {
    return "Bias Rating: Far Right\nExplanation: ZeeNews.India.com is far right, driven by Essel Group's BJP-aligned ownership and a documented history of promoting Hindutva ideology, misinformation, and partisan coverage favoring the ruling party.";
  } else if (domain.includes("scroll.in")) {
    return "Bias Rating: Left-Leaning\nExplanation: Scroll.in generally presents news with a left-leaning perspective, frequently publishing content critical of the current government and right-wing policies while emphasizing social justice issues.";
  } else if (domain.includes("thewire.in")) {
    return "Bias Rating: Left-Leaning\nExplanation: The Wire is known for its left-leaning perspective, often featuring investigations and opinion pieces critical of the current government and right-wing policies while highlighting issues related to civil liberties.";
  } else if (domain.includes("thequint")) {
    return "Bias Rating: Center-Left\nExplanation: The Quint generally presents news with a center-left perspective, often featuring content that is critical of right-wing policies while emphasizing progressive social values.";
  } else if (domain.includes("swarajyamag")) {
    return "Bias Rating: Right-Leaning\nExplanation: Swarajya Magazine openly identifies as a right-leaning publication, presenting news and opinion that supports conservative and nationalist viewpoints while often being supportive of the current government's policies.";
  } else if (domain.includes("theprint")) {
    return "Bias Rating: Center\nExplanation: ThePrint generally maintains a centrist stance, attempting to provide balanced coverage while featuring a diverse range of opinions across the political spectrum.";
  } else if (domain.includes("thenewsminute")) {
    return "Bias Rating: Center-Left\nExplanation: The News Minute, focused on South Indian news, generally presents reporting from a slight center-left perspective, often highlighting social issues and occasionally being critical of government policies.";
  } else if (domain.includes("republicworld")) {
    return "Bias Rating: Right-Leaning\nExplanation: Republic World typically presents news with a right-leaning perspective, with coverage that is often favorable to the current government and nationalist positions.";
  } else if (domain.includes("dainikbhaskar")) {
    return "Bias Rating: Center-Right\nExplanation: Dainik Bhaskar, a Hindi language newspaper, generally maintains a center-right stance with reporting that tends to be somewhat favorable to traditional and nationalist viewpoints.";
  } else if (domain.includes("jagran")) {
    return "Bias Rating: Center-Right\nExplanation: Jagran, a Hindi language newspaper, typically presents news with a center-right perspective, with coverage that often aligns with traditional values and can be somewhat favorable to the current government.";
  } else if (domain.includes("oneindia")) {
    return "Bias Rating: Center-Right\nExplanation: OneIndia generally presents news with a slight center-right perspective, with coverage that tends to be somewhat favorable to the current government's policies.";
  } else if (domain.includes("indiatvnews")) {
    return "Bias Rating: Right-Leaning\nExplanation: India TV typically presents news with a right-leaning perspective, often featuring coverage supportive of nationalist viewpoints and the current government.";
  } else if (domain.includes("news18hindi")) {
    return "Bias Rating: Center-Right\nExplanation: News18 Hindi generally presents news with a center-right perspective, with coverage that tends to be more favorable to the current government's policies.";
  } else if (domain.includes("timesnownews")) {
    return "Bias Rating: Right-Leaning\nExplanation: Times Now typically presents news with a right-leaning perspective, with coverage that is often supportive of the current government and nationalist positions.";
  } else if (domain.includes("financialexpress")) {
    return "Bias Rating: Center-Right\nExplanation: The Financial Express, focused on economic and business news, generally maintains a center-right stance that tends to favor free-market policies and business interests.";
  } else if (domain.includes("theweek")) {
    return "Bias Rating: Center\nExplanation: The Week typically maintains a centrist position, attempting to provide balanced coverage of political issues with reporting from multiple perspectives.";
  } else if (domain.includes("thestatesman")) {
    return "Bias Rating: Center\nExplanation: The Statesman is one of India's oldest newspapers and generally maintains a centrist editorial stance, with reporting that attempts to be balanced and factual.";
  } else if (domain.includes("mid-day")) {
    return "Bias Rating: Center\nExplanation: Mid-Day generally maintains a centrist position with a focus on Mumbai news, presenting relatively balanced reporting on Indian political issues.";
  } else if (domain.includes("businesstoday")) {
    return "Bias Rating: Center-Right\nExplanation: Business Today, focused on economic and business news, generally maintains a center-right perspective that tends to favor free-market policies and business-friendly government initiatives.";
  } else if (domain.includes("telegraphindia")) {
    return "Bias Rating: Center-Left\nExplanation: The Telegraph (India) generally presents news with a center-left perspective, often featuring content that can be critical of the current government, particularly on issues of civil liberties.";
  } else if (domain.includes("freepressjournal")) {
    return "Bias Rating: Center\nExplanation: Free Press Journal typically maintains a centrist position, attempting to provide balanced coverage of political issues from multiple perspectives.";
  } else if (domain.includes("newindianexpress")) {
    return "Bias Rating: Center\nExplanation: The New Indian Express generally maintains a centrist editorial stance, with reporting that attempts to provide balanced coverage of political issues.";
  } else if (domain.includes("tribuneindia")) {
    return "Bias Rating: Center\nExplanation: The Tribune generally maintains a centrist editorial stance, with reporting that attempts to provide balanced coverage of political issues while occasionally leaning slightly left on social policies.";
  } else if (domain.includes("asianage")) {
    return "Bias Rating: Center-Left\nExplanation: The Asian Age generally presents news with a slight center-left perspective, occasionally featuring content critical of right-wing policies.";
  } else if (domain.includes("newsx")) {
    return "Bias Rating: Right-Leaning\nExplanation: NewsX typically presents news with a right-leaning perspective, with coverage that is often favorable to the current government and nationalist positions.";
  } else if (domain.includes("indiatoday")) {
    return "Bias Rating: Center-Right\nExplanation: India Today generally presents news with a center-right perspective, with coverage that tends to be somewhat favorable to the current government while attempting to include multiple viewpoints.";
  } else if (domain.includes("thepioneer")) {
    return "Bias Rating: Center-Right\nExplanation: The Pioneer generally maintains a center-right editorial stance, with reporting that tends to be somewhat favorable to traditional values and the current government.";
  } else if (domain.includes("lokmat")) {
    return "Bias Rating: Center\nExplanation: Lokmat, a Marathi language newspaper, typically maintains a centrist editorial stance, presenting relatively balanced reporting on political issues.";
  } else if (domain.includes("sakaltimes")) {
    return "Bias Rating: Center\nExplanation: Sakal Times, a Marathi language newspaper, generally maintains a centrist position, with reporting that attempts to provide balanced coverage of political issues.";
  } else if (domain.includes("manoramaonline")) {
    return "Bias Rating: Center-Left\nExplanation: Malayala Manorama, a Malayalam language newspaper, generally presents news with a slight center-left perspective, particularly on social issues.";
  } else if (domain.includes("mathrubhumi")) {
    return "Bias Rating: Center-Left\nExplanation: Mathrubhumi, a Malayalam language newspaper, typically presents news with a center-left perspective, often featuring content that emphasizes progressive social values.";
  } else if (domain.includes("deshgujarat")) {
    return "Bias Rating: Center-Right\nExplanation: DeshGujarat generally presents news with a center-right perspective, with coverage that tends to be favorable to the current government and business interests in Gujarat.";
  } else if (domain.includes("greaterkashmir")) {
    return "Bias Rating: Center\nExplanation: Greater Kashmir, focused on news from the Kashmir region, generally attempts to maintain a centrist stance while navigating the complex political landscape of the region.";
  } else {
    // For unknown sites, provide a general response
    return `Bias Rating: Analysis Pending\nExplanation: This news source hasn't been analyzed in our database yet. We recommend checking multiple sources to get a balanced perspective on news from this outlet.`;
  }
} 