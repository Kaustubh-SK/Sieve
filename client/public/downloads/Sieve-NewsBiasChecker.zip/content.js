// This script runs on every page load
const newsPatterns = [
  /news/i, /article/i, /politics/i, /world/i, /opinion/i, /editorial/i,
  /nation/i, /international/i, /daily/i, /post/i, /times/i, /tribune/i,
  /cnn\.com/i, /foxnews\.com/i, /bbc\.co\.uk/i, /nytimes\.com/i, /washingtonpost\.com/i,
  /msnbc\.com/i, /wsj\.com/i, /reuters\.com/i, /apnews\.com/i, /politico\.com/i,
  /theguardian\.com/i, /nbcnews\.com/i, /cbsnews\.com/i, /abcnews\.go\.com/i,
  /huffpost\.com/i, /breitbart\.com/i, /thehill\.com/i, /bloomberg\.com/i,
  /salon\.com/i, /slate\.com/i, /vox\.com/i, /buzzfeed\.com/i,
  /drudgereport\.com/i, /dailykos\.com/i, /motherjones\.com/i
];

// Check if the current page is a news site
function isNewsSite() {
  const currentUrl = window.location.hostname;
  return newsPatterns.some(pattern => pattern.test(currentUrl));
}

// If this is a news site, notify the background script
if (isNewsSite()) {
  chrome.runtime.sendMessage({ 
    action: 'newsPageDetected', 
    url: window.location.hostname 
  });
}

// Listen for messages from background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getPageContent') {
    // Extract page content for analysis
    const title = document.title;
    const metaDescription = document.querySelector('meta[name="description"]')?.content || '';
    const h1Content = Array.from(document.querySelectorAll('h1')).map(h => h.textContent).join(' ');
    const mainContent = document.querySelector('main')?.textContent || '';
    
    sendResponse({
      title: title,
      metaDescription: metaDescription,
      h1Content: h1Content,
      mainContent: mainContent.substring(0, 1000) // Limit content size
    });
  }
  return true; // Keep the message channel open for async response
}); 